 <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="dashboard.php"><img class="main-logo" src="img/gas-cylinder.png" alt="OGBS"  /> </a>
                <strong><a href="dashboard.php"><img src="img/gas-cylinder.png" alt="OGBS" /></a></strong>
                <hr />
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        
                        <li>
                            <a title="Landing Page" href="dashboard.php" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Dashboard</span></a>
                        </li>
                        <li>
                            <a  href="new-connection.php" aria-expanded="false"><i class="fa fa-file"></i> <span class="mini-click-non"> New Connection</span></a>
                            
                        </li>
                        <li>
                            <a  href="book-cylinder.php" aria-expanded="false"><i class="fa fa-database"></i> <span class="mini-click-non">Book Cylinder</span></a>
                            
                        </li>
                        <li>
                            <a  href="booking-history.php" aria-expanded="false"><i class="fa fa-files-o"></i> <span class="mini-click-non">Booking History</span></a>
                            
                        </li>
                       <li>
                            <a  href="search.php" aria-expanded="false"><span class="educate-icon educate-search icon-wrap"></span> <span class="mini-click-non">Search</span></a>
                            
                        </li>
                     
                    
                    </ul>
                </nav>
            </div>
        </nav>
    </div>